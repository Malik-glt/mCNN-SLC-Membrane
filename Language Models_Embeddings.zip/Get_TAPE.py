import os
import numpy as np
import torch
from tape import ProteinBertModel, TAPETokenizer

# Specify the folder containing FASTA files
fasta_folder = 'D:/SLC/Secondary/Sec_Train'  # Update with your folder path
output_folder = 'D:/SLC/ProtBertEmb/Train'

# Load the ProteinBert model and tokenizer
model = ProteinBertModel.from_pretrained('bert-base')
tokenizer = TAPETokenizer(vocab='iupac')  # iupac is the vocab for TAPE models

# Create the output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Get a list of FASTA files in the folder
fasta_files = [f for f in os.listdir(fasta_folder) if f.endswith('.fasta')]

# Loop through each FASTA file, generate embeddings, and save them
for fasta_file in fasta_files:
    # Read the sequence from the FASTA file
    with open(os.path.join(fasta_folder, fasta_file), 'r') as file:
        sequence = ''.join(file.read().split('\n')[1:])  # Skip the header line

    # Tokenize the sequence
    token_ids = torch.tensor([tokenizer.encode(sequence)])

    # Generate the protein embeddings
    with torch.no_grad():
        outputs = model(token_ids)
        sequence_output = outputs[0]  # Extract the correct element from the tuple

    # Extract the embeddings as a numpy array
    embedding_array = sequence_output[0].detach().cpu().numpy()

    # Define the output file path based on the input file name
    output_file = os.path.join(output_folder, f'{fasta_file.split(".fasta")[0]}.npy')  # Remove "_protbert" suffix

    # Save the embeddings to a numpy file
    np.save(output_file, embedding_array)

    print(f'ProtBert embeddings saved to {output_file}')

print('Embedding generation complete.')
